﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    internal class DataStore
    {

            public static List<Student> data = new List<Student>(); //stereotype array list

    }
}
