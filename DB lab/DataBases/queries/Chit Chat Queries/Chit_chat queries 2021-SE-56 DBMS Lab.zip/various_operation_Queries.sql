--use chit_chat

--SELECT * FROM Users;
--returns all the enteries


--this querie will return the rows in ordered form in terms of most recent entry
--SELECT * FROM Interactions ORDER BY timestamp DESC;


--this querie returns the top 5 rows in desc order
--SELECT TOP 5 post_id, content, user_id
--FROM Posts
--ORDER BY user_id DESC; 


--this querie will return all the rows whose username starts with S and contains total of 6 characters
--SELECT * FROM Users WHERE username LIKE 'S_____';


--select *from Posts where content like '%,%'


--Select the most recent 3 interactions and their associated user and post information:
--select top 3 Interactions.*, Users.username, Posts.content
--from Interactions
--INNER JOIN Users ON Interactions.user_id = Users.user_id
--INNER JOIN Posts ON Interactions.post_id = Posts.post_id
--order by Interactions.timestamp ;


--The data types text and varchar are incompatible in the equal to operator.
--SELECT *
--FROM Users
--WHERE CAST(username AS varchar) = 'Hammad'


--Count the number of interactions for each post
SELECT post_id,user_id, COUNT(*) AS num_interactions
FROM Interactions
WHERE post_id IS NOT NULL
GROUP BY post_id, user_id;